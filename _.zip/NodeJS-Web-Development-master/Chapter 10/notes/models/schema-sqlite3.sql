CREATE TABLE IF NOT EXISTS notes (
    notekey VARCHAR(255),
    title   VARCHAR(255),
    author  VARCHAR(255),
    body    TEXT
);